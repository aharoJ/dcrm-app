import mysql.connector

dataBase = mysql.connector.connect(
    host="localhost", user="root", passwd="AppleYaretzy1998!"
)

# prepare a curser object
cursorObject = dataBase.cursor()

# create database
cursorObject.execute("CREATE DATABASE crmdb")

print("Database created sucessfully")
